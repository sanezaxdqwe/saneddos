# ProxyDDoS

Lütfen dikkatli kullanınız.

Not: Sadece eğitim amaçlı kodlanmıştır. Hedef websitesine yoğun bir saldırı yapılacağından dolayı oluşacak tüm hasarların sorumluluğu yazılımı kullanan kişiye aittir.

Kullanım: python ddos.py
